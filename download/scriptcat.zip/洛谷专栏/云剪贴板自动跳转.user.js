// ==UserScript==
// @name         洛谷专栏/云剪贴板自动跳转
// @version      2.3
// @description  洛谷专栏/云剪贴板自动重定向至相关保存站
// @author       pbcoding
// @match        https://www.luogu.com.cn/*
// @match        https://www.luogu.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = window.location.href;
    const path = window.location.pathname;
    const host = window.location.hostname;

    if (host === 'www.luogu.com') {
        if (path.startsWith('/article/') || path.startsWith('/paste/')) {
            const newUrl = `https://www.luogu.me${path}`;
            window.location.replace(newUrl);
            return;
        }
    }

    if(host === 'www.luogu.com.cn' && (path.startsWith('/article/') || path.startsWith('/paste/'))) {
        const warningTitle = document.querySelector('body > div:nth-child(1) > div > h3');
        if (document.title == '安全访问中心 - 洛谷' && warningTitle.textContent.trim() == '即将离开洛谷') {
            const urlElement = document.querySelector('#url');
            if (urlElement) {
                urlElement.textContent = urlElement.textContent
                    .replace('luogu.com', 'luogu.me')
                    .replace('luogu.com.cn', 'luogu.me');
            }

            const continueLink = document.querySelector('body > div:nth-child(1) > div > p:nth-child(5) > a');
            if (continueLink) {
                continueLink.href = continueLink.href
                    .replace('luogu.com', 'luogu.me')
                    .replace('luogu.com.cn', 'luogu.me');
            }
        }
       return;
    }
})();
