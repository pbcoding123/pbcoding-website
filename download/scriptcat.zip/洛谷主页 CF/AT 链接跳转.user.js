// ==UserScript==
// @name         洛谷主页 CF/AT 链接跳转
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  在洛谷主页本站公告上方添加一个 CF/AT 跳转的卡片
// @author       pbcoding
// @match        https://www.luogu.com.cn/
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';
    function createCard() {
        const article = document.createElement('div');
        article.className = 'lg-article custom-luogu-card';
        article.innerHTML = `
            <h2>CF/AT 链接跳转</h2>
            <div class="am-input-group am-input-group-primary am-input-group-sm">
                <input type="text" class="am-form-field" placeholder="粘贴 CF 和 AT 的完整链接" id="pb_link">
            </div>
            <p>
                <button class="am-btn am-btn-danger am-btn-sm" id="pb_jump">跳转</button>
            </p>
        `;
        return article;
    }
    
    function insertJS(){
        const input=document.getElementById('pb_link');
        const button=document.getElementById('pb_jump');
        button.addEventListener('click', function(){
            const v=input.value;
            if(v.startsWith("https://codeforces.com/problemset/problem/")){
                let id=v.substr(42);
                const ch=id[id.length-1];
                id = id.substr(0, id.length-2);
                window.location.replace("https://www.luogu.com.cn/problem/CF"+id+ch);
            }
            else if(v.startsWith("https://atcoder.jp/contests/")){
                const pos=v.lastIndexOf('/');
                const id=v.substr(pos+1);
                window.location.replace("https://www.luogu.com.cn/problem/AT_"+id);
            }
            else{
                alert("Unknown url.\n");
            }
        });
    }

    function insertCard() {
        const headings = document.querySelectorAll('h2');
        
        for (let heading of headings) {
            if (heading.textContent.trim() === '本站公告') {
                const announcementModule = heading.closest('.lg-article, .am-panel, [class*="panel"]');
                
                if (announcementModule && announcementModule.parentElement) {
                    const card = createCard();
                    announcementModule.parentElement.insertBefore(card, announcementModule);
                    insertJS();
                    return true;
                }
            }
        }
        
        return false;
    }
    
    let attempts = 0;
    const interval = setInterval(() => {
        attempts++;
        if (insertCard() || attempts >= 30) {
            clearInterval(interval);
        }
    }, 100);
})();