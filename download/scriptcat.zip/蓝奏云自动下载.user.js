// ==UserScript==
// @name        蓝奏云自动下载
// @version     1.5
// @description 蓝奏云下载链接点开后一秒内自动下载
// @author      pbcoding
// @match       https://*.lanzn.com/i*
// @match       https://*.lanzouv.com/i*
// @match       https://*.lanzouu.com/i*
// @match       https://*.lanwp.com/i*
// @noframes
// @run-at      document-idle
// ==/UserScript==

(async function() {
    'use strict';
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    const f=document.querySelector('iframe');
    async function get(){
        let button=null;
        while(button===null){
            button = f.contentDocument.querySelector(".txt");
            await sleep(100);
        }
        return button.href;
    }
    const s=await get();
    console.log(s);
    window.location.replace(s);
})();
