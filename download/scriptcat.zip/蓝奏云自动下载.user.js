// ==UserScript==
// @name        蓝奏云自动下载
// @version     2.4
// @description 蓝奏云下载链接点开后一秒内自动下载，并添加跳转按钮以便自动输入密码。
// @author      pbcoding
// @match       https://*.lanzn.com/i*
// @match       https://*.lanzouv.com/i*
// @match       https://*.lanzouu.com/i*
// @match       https://*.lanwp.com/i*
// @match       https://pc.woozooo.com/mydisk.php
// @match       https://pc.woozooo.com/u
// @noframes
// @run-at      document-idle
// ==/UserScript==

(async function() {
    'use strict';
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    if(window.location.hostname=="pc.woozooo.com"){
        const fra=document.querySelector('#mainframe');
        async function get(){
            let b=null;
            while(b===null || b.URL==='about:blank'){
                b = fra.contentDocument;
                await sleep(100);
            }
            return b;
        }
        const frame=await get();

        const sha=frame.querySelector('#f_sha');
        const sha1=frame.querySelector('#f_sha1');
        const a=frame.createElement('a');
        a.id = 'link-btn';
        a.textContent = '打开';
        a.href = '/';
        a.target = '_blank';
        a.className = 'f_sela';
        sha.insertBefore(a, sha1.nextSibling);
        const ob=new MutationObserver((mutations)=>{
            for(const m of mutations){
                if(m.type=='childList'){
                    const url=sha1.textContent;
                    if(url!='获取中...'){
                        const idx=url.indexOf('密码:');
                        if(idx==-1){
                            a.href = url;
                        }
                        else{
                            const pre=url.substring(0, idx);
                            const bak=url.substring(idx+3);
                            a.href = pre+'?pwd='+bak;
                        }
                    }
                }
            }
        });
        ob.observe(sha1, {childList:true});
    }
    else{
        console.log(window.location.search);
        if(window.location.search.startsWith('?pwd=')){ // pwd
            const pwd=window.location.search.substring(5);
            const input=document.querySelector('#pwd');
            input.value=pwd;
            down_p();
            await sleep(500);
            const buttondiv=document.querySelector('#downajax');
            const button=buttondiv.querySelector('a');
            window.location.replace(button.href);
        }
        else{ // no pwd
            const f=document.querySelector('iframe');
            async function get(){
                let button=null;
                while(button===null){
                    button = f.contentDocument.querySelector(".txt");
                    await sleep(100);
                }
                return button.href;
            }
            const s=await get();
            await sleep(1000);
            console.log(s);
            window.location.replace(s);
        }
    }
})();
