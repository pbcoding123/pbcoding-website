// ==UserScript==
// @name         Hydro 自动展开所有未完成训练章节
// @version      2.1
// @description  Hydro 自动展开所有未完成训练章节，并添加一键展开按钮
// @author       pbcoding
// @match        *://*.goj.wiki/training/*
// @match        *://*.goj.wiki/d/*/training/*
// @noframes
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    function expandUnfinished() {
        const details = document.querySelectorAll('.training__section__detail');
        details.forEach(function(detail) {
            const section = detail.closest('.training__section');
            if (section) {
                const header = section.querySelector('.section__header');
                if (header && header.innerText.includes('已完成')) {
                    return; // 已完成，跳过
                }
            }
            detail.style.display = 'block';
        });
    }

    function expandAll() {
        const details = document.querySelectorAll('.training__section__detail');
        details.forEach(function(detail) {
            detail.style.display = 'block';
        });
    }
    function closeAll() {
        const details = document.querySelectorAll('.training__section__detail');
        details.forEach(function(detail) {
            detail.style.display = 'none';
        });
    }

    expandUnfinished();

    const targetLink = document.querySelector('a[name="training__sidebar__collapse"]');
    targetLink.addEventListener('click', function(e) {
        e.preventDefault();
        closeAll();
    });

    if (targetLink) {
        const targetLi = targetLink.parentElement; // 找到它所在的 <li>
        const targetOl = targetLi.parentElement;   // 找到它所在的 <ol>

        if (!targetOl.querySelector('.menu__item--custom')) {
            const newLi = document.createElement('li');
            newLi.className = 'menu__item menu__item--custom';
            
            const newLink = document.createElement('a');
            newLink.className = 'menu__link';
            newLink.href = 'javascript:;';
            newLink.innerHTML = '<span class="icon icon-expand_more"></span> 展开所有章节';
            
            newLi.appendChild(newLink);

            targetOl.insertBefore(newLi, targetLi);

            // 绑定点击事件
            newLink.addEventListener('click', function(e) {
                e.preventDefault();
                expandAll();
            });




            const newLi2 = document.createElement('li');
            newLi2.className = 'menu__item menu__item--custom';
            
            const newLink2 = document.createElement('a');
            newLink2.className = 'menu__link';
            newLink2.href = 'javascript:;';
            newLink2.innerHTML = '<span class="icon icon-expand_more"></span> 展开所有未完成章节';
            
            newLi2.appendChild(newLink2);

            targetOl.insertBefore(newLi2, targetLi);

            // 绑定点击事件
            newLink2.addEventListener('click', function(e) {
                e.preventDefault();
                expandUnfinished();
            });
        }
    } else {
        console.warn('未找到 training__sidebar__collapse 元素');
    }
})();
