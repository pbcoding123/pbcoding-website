// ==UserScript==
// @name         洛谷背景补丁
// @version      1.0
// @description  Luogu Background Fixed
// @author       pbcoding
// @match        https://www.luogu.com.cn/*
// @noframes
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';
    function articleBackground(){
        document.querySelectorAll('div[data-v-e9b0168c-s]').forEach(function(d){
            d.style.backgroundColor = '';
        });
    }
    const path=window.location.pathname;
    if(path.startsWith('/article/')){
        articleBackground();
    }
})();